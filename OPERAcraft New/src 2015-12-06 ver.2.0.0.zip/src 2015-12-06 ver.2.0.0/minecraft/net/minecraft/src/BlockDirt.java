package net.minecraft.src;

public class BlockDirt extends Block
{
    protected BlockDirt(int par1)
    {
        super(par1, Material.ground);
        this.setCreativeTab(CreativeTabs.tabBlock);
    }
}
