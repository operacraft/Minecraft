package argo.jdom;

public class JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException
{
    JsonNodeDoesNotMatchJsonNodeSelectorException(String par1Str)
    {
        super(par1Str);
    }
}
